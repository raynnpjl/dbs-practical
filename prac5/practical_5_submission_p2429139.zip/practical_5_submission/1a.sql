SELECT citizenship FROM staff
ORDER BY citizenship DESC;