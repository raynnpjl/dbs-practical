SELECT dept_code, staff_name FROM staff
ORDER BY dept_code DESC, staff_name DESC;