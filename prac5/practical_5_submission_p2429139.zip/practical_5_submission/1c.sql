SELECT staff_name AS "Name of Staff", dob AS "Date of Birth" FROM staff
ORDER BY dob ASC;