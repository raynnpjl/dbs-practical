SELECT DISTINCT citizenship FROM staff
ORDER BY citizenship DESC;
