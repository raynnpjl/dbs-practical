SELECT COUNT(staff_no) AS "Number of FT Staff" FROM staff
WHERE type_of_employment = 'FT';